/* University Group Project
World University of Bangladesh
Project Name : Library Management System
Date : 21 April 2016 */

#include<iostream>
#include<cstring> // strcpy
#include<stdlib.h> // exit(0)
#include<iomanip> // setw


using namespace std;

const int MAX = 200;

// book class create
class Book
{
public:
    char isbn[20];
    char name[30];
    char author[30];
    char copies[3];
    char catagory[15];

};

// Library class create
class Library
{
public:
    int numBooks;
    Book book[MAX];

    //constructor
    Library()
    {
        numBooks = 0;
    }

    void insertBook( char bIsbn[], char bName[], char bAuthor[], char bCopies[], char bCatagory[]);

    void deleteBook(char bIsbn[]);

    Book *bookSearch(char bIsbn[]);

};

// insertBook function
void Library::insertBook(char bIsbn[], char bName[], char bAuthor[], char bCopies[], char bCatagory[])
{
    strcpy( book[numBooks].isbn, bIsbn );
    strcpy( book[numBooks].name, bName );
    strcpy( book[numBooks].author, bAuthor );
    strcpy( book[numBooks].catagory, bCatagory);
    strcpy( book[numBooks].copies, bCopies);

    cout<< "Book Inserted Successfully."<<endl<<endl;

    ++numBooks;
}

// deleteBook function
void Library::deleteBook(char bIsbn[])
{
    for(int i = 0; i < numBooks; i++)
    {
        if(strcmp( bIsbn, book[i].isbn) == 0)
        {
            for(int j = i; j < numBooks; j++)
            {
                book[j] = book[ j + 1 ];
            }
            cout<<"Book Deleted Successfully"<<endl<<endl;
            //return; // do something
        }
    }
    cout<<"!!! "<<bIsbn << " is not created !!!"<< endl<<endl;
}


// book item search function
Book *Library::bookSearch(char bIsbn[])
{
    for(int i = 0; i < numBooks; i++)
    {
        if(strcmp(bIsbn, book[i].isbn) == 0)
        {
            return &book[i];
        }
    }
    return NULL;
}

// main function
int main()
{
    Library library;
    char isbn[20], name[30],  author[30],  catagory[20],  copies[3];
    char option;



    cout<<"\t\t   Welcome to Library Management System"<<endl<<endl;
    // infinite loop
    int a = 1;
    while(a)
    {
        cout<<"\t\t\t Enter Your Option"<<endl;
        cout<<"\t\t\t--------------------"<<endl;
        cout<<"\t\t\t I -> Insert Book Item"<<endl;
        cout<<"\t\t\t S -> Search Book Item"<<endl;
        cout<<"\t\t\t L -> List of Book Item"<<endl;
        cout<<"\t\t\t D -> Delete Book Item"<<endl;
        cout<<"\t\t\t X -> EXIT"<<endl;


        cout<<" -> ";
        cin.getline( isbn, 80);

        option = tolower(isbn[0]);

        switch(option)
        {
        case 'i' :
            cout<<"Menu : Insert Book Item"<<endl;
            cout<<"------------------------"<<endl;
            cout<<"Enter Book ISBN \t: -> ";
            cin.getline(isbn, 80);
            cout <<"Enter Book Name \t: -> " ;
            cin.getline(name, 80);
            cout<<"Enter Author Name \t: -> ";
            cin.getline(author, 80);
            cout<<"Enter Book Copies \t: -> ";
            cin.getline(copies, 80);
            cout<< "Enter Category Name \t: -> ";
            cin.getline(catagory, 80);

            library.insertBook(isbn, name, author, copies, catagory);

            break;

        case 'd' :
            cout<<"Menu : Delete Book Item"<<endl;
            cout<<"------------------------"<<endl;
            cout<<"Enter ISBN of Book Item\t -> ";
            cin.getline(isbn, 80);
            library.deleteBook(isbn);

            break;

        case 's' :
            cout<<"Menu : Search Book Item"<<endl;
            cout<<"------------------------"<<endl;
            cout<<"Enter ISBN of Book Item\t -> ";
            cin.getline(isbn, 80);

            Book *item;
            item = library.bookSearch(isbn);
            if( item != NULL )
            {
                cout<< "|  ISBN   |        Name       |       Author      | Copies  |   Category   |"<<endl;
                cout<<"----------------------------------------------------------------------------"<<endl;

                cout<<"|"<<setw(9)<<item->isbn<<"|"<<setw(19)<< item->name<<"|"<< setw(19)<<item->author <<"|"<< setw(9)<<item->copies<<"|"<<setw(14)<<item->catagory<<"|"<<endl;

            }
            else
            {
                cout<<"!!! "<<isbn<<" is not found !!!"<<endl<<endl;
            }


            break;

        case 'l' :
            cout<<"Menu : List of Book Item"<<endl;
            cout<<"------------------------"<<endl;

            if(library.numBooks != 0)
            {
                    cout<< "|  ISBN   |        Name       |       Author      | Copies  |   Category   |"<<endl;
                    cout<<"----------------------------------------------------------------------------"<<endl;



                    for( int i = 0; i < library.numBooks; i++)
                    {
                        cout<<"|"<<setw(9)<<library.book[i].isbn<<"|"<<setw(19)<< library.book[i].name<<"|"<< setw(19)<<library.book[i].author <<"|"<< setw(9)<<library.book[i].copies<<"|"<<setw(14)<<library.book[i].catagory<<"|"<<endl;
                        cout<<"----------------------------------------------------------------------------"<<endl;
                    }
                    cout<<endl;
                    cout<<"\t\t\t-----------------------"<<endl;
                    cout<<"\t\t\t Total Book Items : "<< library.numBooks <<endl<<endl;
            }
            else
            {
                cout<<"!!! Empty Book List !!!"<<endl<<endl;
            }
            break;

        case 'x' :
            exit(0); // program terminate
            break;

        default:
            cout<<"!!! Please Select Right Option !!!"<<endl<<endl;

        }

    }

}
